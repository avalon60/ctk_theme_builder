"""
CustomTkinter ToolTip
Author: Akash Bora
This is a tooltip/pop-up widget made with customtkinter.
Homepage: https://github.com/Akascape/CTkToolTip
"""

__version__ = '0.2'

from .ctk_tooltip import CTkToolTip

